
const express = require('express'); 
const process = require('process');
const path = require('path');
const service = require('./services/mongodb-task-service.jsx');
const bodyParser = require('body-parser');

const app = express(); 
const port = 4000


app.use(bodyParser.json());

app.use((req, resp, next) => {
    console.log('reached the CORS middleware...');
    resp.set('Access-Control-Allow-Origin', '*');
    resp.set('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE');
    resp.set('Access-Control-Allow-Headers', '*');
    next(); 
})

app.get('/api/todos/', (req, resp) => {
    service.getAllTasks()
        .then(data => resp.json(data));
});

app.post('/api/todos/', (req, resp) => {
    service.addNewTask(req.body)
        .then(data => resp.json(data))
        .catch(err => console.log(err));
})

app.listen(port, () => console.log(`server started at http://localhost:${port}`))