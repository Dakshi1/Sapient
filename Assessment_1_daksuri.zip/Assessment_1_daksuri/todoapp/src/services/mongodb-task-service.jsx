const { MongoClient, ObjectId } = require('mongodb');
const url = 'mongodb://localhost:27017'
const requiredFields = ['task'];


module.exports.addNewTask = async (task) => {
    if (!task || typeof task !== 'object') {
        throw 'contact was not supplied or was not an object!';
    }
    
    if (task==='') {
        throw 'required fields missing';
    }
    const conn = await MongoClient.connect(url, { useNewUrlParser: true });
    const tasks = conn.db('assessment1').collection('todos');
    const response = await tasks.insertOne(task);
    conn.close();
    task._id = response.insertedId;
    return task;
}



module.exports.getAllTasks = async (options = {}) => {
    
    const conn = await MongoClient.connect(url, { useNewUrlParser: true });
    const tasks = conn.db('assessment1').collection('todos');
    
    const tasksData = await tasks.find({}, {}).toArray();
    conn.close();
    return tasksData;
}